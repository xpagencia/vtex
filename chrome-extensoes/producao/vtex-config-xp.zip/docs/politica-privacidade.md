# Política de Privacidade

A política de privacidade do "VTEX-Config - XP" descreve como tratamos as informações pessoais quando você usa a nossa extensão.

## Dados de registro

Coletamos informações do HTML do seu site para exibir de forma mais simplificada na extensão. Em nenhum momento armazenamos tais informações nos nossos servidores ou qualquer outro local que não seja na própria extensão. Tais informações ficam apenas na memória da sua própria máquina. Assim que você fecha a aba do navegador, as informações são apagadas.

## Extensão do navegador

Você não precisa fornecer nenhuma informação pessoal para baixar e usar a extensão do navegador.
Não rastreamos seu comportamento de navegação ou qualquer informação que possa ser rastreada até você pessoalmente.

## Dados pessoais

Nós não lemos, armazenamos ou compartilhamos essas informações.

### Dúvidas

Usem o issues https://github.com/xpagencia/vtex/issues que respondo em até 5 dias.

Fiquem com Deus.
